Installation
============

To install the libraries, you need to place the folders contained within the download zip into your "libraries" folder. You can find it within your Arduino IDE distribution within the "hardware" folder. Be sure to restart the IDE if it was running.

On a Mac, you will want to create a folder named "libraries" in in the "Documents" -> "Arduino" folder within your home directory. Place the folders contained in the download zip there (and restart the IDE, if it was running during this process).

Additional information can be found on the Arduino website: http://www.arduino.cc/en/Hacking/Libraries

Documentation
============

Documentation for the individual libraries is available here: http://gkaindl.com/software/arduino-ethernet